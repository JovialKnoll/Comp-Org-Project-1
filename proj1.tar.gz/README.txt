Brett Kaplan and Jeff Johnston

This program is for Python 2.6-2.7.  It does *not* work in python 3.
it is a single program, called in the command line with:
    
    python main.py [-PART2]

If the -PART2 flag is used, it will start 3/4 of the processes at a
random time as defined in the assignment.
All tunable variables can be found from lines 18-20 in main.py
